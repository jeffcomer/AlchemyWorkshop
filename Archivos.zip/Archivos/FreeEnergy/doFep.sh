kT=$( awk -v OFMT=%.15g 'BEGIN {print 0.001987191*310}' )

for sys in fep{0..4}_graph_hybrid_PPF_PPW_vac fep{0..4}_hybrid_PPF_PPW_vac
do
    tclsh fepContinuous.tcl $kT ../output/$sys.*.fepout ${sys}.dat
done
