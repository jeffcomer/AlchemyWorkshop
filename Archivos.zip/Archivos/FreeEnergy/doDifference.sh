date=$( date +%F )
out=fep_difference_${date}.dat
:>$out

for f in fep{0..4}_graph_hybrid_PPF_PPW_vac.dat
do
    suf=${f#*_graph_}
    pre=${f%%_*}
    f1=${pre}_${suf}

    if [[ -f $f && -f $f1 ]]; then
	dg2=$( awk -v OFMT=%.15g '/^ΔA_total/ {print $2}' $f )
	edg2=$( awk -v OFMT=%.15g '/^FREE_ENERGY_FINAL/ {print $4}' $f )
	dg1=$( awk -v OFMT=%.15g '/^ΔA_total/ {print $2}' $f1 )
	edg1=$( awk -v OFMT=%.15g '/^FREE_ENERGY_FINAL/ {print $4}' $f1 )
	
	ddg=$( awk "BEGIN { print $dg2 - $dg1 }" )
	eddg=$( awk "BEGIN { print sqrt(${edg2}**2 + ${edg1}**2) }" )
	
	printf "%-35s ΔG2 = %8.3f, ΔG1 = %8.3f, ΔΔG = %8.3f ± %8.3f\n" $f $dg2 $dg1 $ddg $eddg  >> $out
    else
	echo "$f1 or $f does not exist."
    fi
done
cat $out
